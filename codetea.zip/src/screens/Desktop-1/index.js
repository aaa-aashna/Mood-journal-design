import React from "react";
export default (props) => {
	return (
		<div 
			style={{
				display: "flex",
				flexDirection: "column",
				background: "#FFFFFF",
			}}>
			<div 
				style={{
					height: 1024,
					alignSelf: "stretch",
					display: "flex",
					flexDirection: "column",
					backgroundImage: 'url(https://storage.googleapis.com/tagjs-prod.appspot.com/v1/se9wifkIKd/v54ncv33_expires_30_days.png)',
					backgroundSize: "cover",
					backgroundPosition: "center",
				}}>
				<div 
					style={{
						flex: 1,
						alignSelf: "stretch",
						display: "flex",
						flexDirection: "column",
						alignItems: "flex-start",
					}}>
					<div 
						style={{
							alignSelf: "stretch",
							display: "flex",
							flexDirection: "column",
							alignItems: "flex-end",
							marginBottom: 127,
						}}>
						<div 
							style={{
								width: 164,
								display: "flex",
								flexDirection: "column",
								background: "#9CFF7B",
								borderRadius: 26,
								border: `1px solid #00000000`,
								paddingTop: 11,
								paddingBottom: 11,
								marginRight: 48,
								boxShadow: "0px 0px 8px #9DFF7C",
							}}>
							<span 
								style={{
									color: "#000000",
									fontSize: 24,
									textAlign: "center",
									marginLeft: 46,
									marginRight: 46,
								}} >
								{"Sign In"}
							</span>
						</div>
					</div>
					<img
						src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/se9wifkIKd/xt1xeicg_expires_30_days.png"} 
						style={{
							width: 1377,
							height: 533,
							marginLeft: 62,
							objectFit: "fill",
						}}
					/>
				</div>
			</div>
		</div>
	)
}